import customtkinter
from tkinter import messagebox
from PIL import Image
from cusfunct.minmax import remove_min_max
from dashboard.home import mainboxwin

def show_splash():
    splash = customtkinter.CTk()
    splash.overrideredirect(True)
    global sw,sh
    # Center splash screen
    sw = splash.winfo_screenwidth()
    sh = splash.winfo_screenheight()
    x = (sw // 2) - 200
    y = (sh // 2) - 138 - 50
    
    splash.geometry(f"400x276+{x}+{y}")
    # Load and display image
    splash_image = customtkinter.CTkImage(dark_image=Image.open('img/src1.png'), size=(400, 276))
    image_label = customtkinter.CTkLabel(splash, image=splash_image, text="")
    image_label.pack()
    
    # Add loading text label
    loading_text = customtkinter.CTkLabel(
        splash,
        text="Starting application...",
        font=("Consolas", 12),
        text_color="white",
        bg_color="#333333",
        corner_radius=5
    )
    loading_text.place(relx=0.5, rely=0.69, anchor="center")
    
    # Loading messages sequence
    messages = [
        "Importing modules...",
        "Loading configuration...",
        "Initializing database...",
        "Starting services...",
        "Ready!"
    ]
    
    def update_loading_message(index=0):
        if index < len(messages):
            loading_text.configure(text=messages[index])
            splash.after(50, update_loading_message, index + 1)
        else:
            splash.destroy()
    
    splash.after(1000, update_loading_message)  # Start messages after 1 second
    splash.mainloop()


def login():
    app = customtkinter.CTk()
    app.title("School Monitoring System 1.0")
    

    x = (sw // 2) - 208
    y = (sh // 2) - 138 - 50
    
    app.geometry(f"400x276+{x}+{y}")

    app.resizable(False, False)
    
    remove_min_max(app)
    # UI Elements
    my_image = customtkinter.CTkImage(dark_image=Image.open('img/src2.png'), size=(400, 276))
    customtkinter.CTkLabel(app, image=my_image, text="").grid()
    
    userna = customtkinter.CTkEntry(app,fg_color="#efbe4f",text_color="black",placeholder_text="Username:",placeholder_text_color="#333333",font=("Arial",11,"bold"))
    userna.place(relx=0.35, rely=0.43, anchor="center")
    
    pas = customtkinter.CTkEntry(app, fg_color="#efbe4f", text_color="black", show="*",placeholder_text="Password:",placeholder_text_color="#333333", font=("Arial", 11, "bold"))
    pas.place(relx=0.71, rely=0.43, anchor="center")
    
    def verify_login():
        if not (username := userna.get()) or not (password := pas.get()):
            messagebox.showwarning("Error", "Please enter both fields")
            return
        
        try:
            with open('cred/credentials.txt') as file:
                if any(line.strip().split(',') == [username, password] for line in file):
                    app.destroy()
                    mainboxwin()
                else:
                    messagebox.showerror("Failed", "Invalid credentials")
        except FileNotFoundError:
            messagebox.showerror("Error", "Credentials file missing")
    
    customtkinter.CTkButton(app, text="Login", fg_color="#032b44", hover_color="#efbe4f",
                 text_color='white', font=("Arial", 13, "bold"), command=verify_login
                 ).place(relx=0.5, rely=0.712, anchor="center")
    
    app.mainloop()

import sys
if sys.platform == "win32":
    import ctypes

def remove_min_max(root):
    if sys.platform != "win32": return
    hwnd = ctypes.windll.user32.GetParent(root.winfo_id())
    style = ctypes.windll.user32.GetWindowLongW(hwnd, -16)
    style &= ~0x00020000  # WS_MINIMIZEBOX
    style &= ~0x00010000  # WS_MAXIMIZEBOX
    style |=  0x00080000  # WS_SYSMENU
    ctypes.windll.user32.SetWindowLongW(hwnd, -16, style)
    ctypes.windll.user32.SetWindowPos(hwnd, 0, 0,0,0,0, 0x027)
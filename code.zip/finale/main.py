from SplashScreen.splash_N_login import show_splash,login


if __name__ == "__main__":
    show_splash()
    login()


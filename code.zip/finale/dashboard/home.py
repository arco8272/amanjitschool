import customtkinter
from PIL import Image
import threading

import subprocess
from trakinghead.test import trackp

from cusfunct.minmax import remove_min_max
from cusfunct.cen import center_window






def mainboxwin():
    win = customtkinter.CTk()
    win.title("Dashboard")
    win.geometry(f"720x500")
    win.resizable(False,False)

    widgd= customtkinter.CTkFrame(win,height=450,width=420,fg_color="white",corner_radius=30)
    widgd.place(x=275,y=42)

    center_window(win)


    remove_min_max(win)


    def logout():
        win.destroy()
    sidebar = customtkinter.CTkFrame(win,height=500,width=250,fg_color="#0f3b43",corner_radius=0)
    sidebar.place(x=0,y=0)

    dasboardname = customtkinter.CTkLabel(sidebar,text="School Monitoring System",text_color="#f5f5f5",font=customtkinter.CTkFont(size=17,weight="bold"))
    dasboardname.place(x=11,y=10)

    sidebard = customtkinter.CTkLabel(sidebar,text="__________________________________",fg_color="transparent",font=customtkinter.CTkFont(size=17),text_color="#0e2d33")
    sidebard.place(x=0,y=38)

    settingbt = customtkinter.CTkButton(sidebar,text='⚙️',command=lambda:get_selected_value("details"),fg_color="#1c4a52",hover_color="#1a5c66",width=70,height=40,corner_radius=5)
    settingbt.place(x=15,y=80)

    themebt = customtkinter.CTkButton(sidebar,text='⭐',command=lambda:get_selected_value("guide"),fg_color="#1c4a52",hover_color="#1a5c66",width=70,height=40,corner_radius=5)
    themebt.place(x=90,y=80)

    infobt = customtkinter.CTkButton(sidebar,text='ℹ',command=lambda:get_selected_value("test"),fg_color="#1c4a52",hover_color="#1a5c66",width=70,height=40,corner_radius=5)
    infobt.place(x=165,y=80)

    home_btn = customtkinter.CTkButton(sidebar,text="∞ Home",command=lambda:get_selected_value("home"),fg_color="transparent",hover_color="#164a52",anchor="w",height=40,width=220,corner_radius=5,text_color="white")
    home_btn.place(x=15, y=150)

    home_btn = customtkinter.CTkButton(sidebar,text="ℹ️ About Us",command=lambda:get_selected_value("page2"),fg_color="transparent",hover_color="#164a52",anchor="w",height=40,width=220,corner_radius=5,text_color="white")
    home_btn.place(x=15, y=200)


    shutdownbtn = customtkinter.CTkButton(sidebar,text="⏻",fg_color="transparent",hover_color="#164a52",width=40,height=40,corner_radius=5,command=logout)
    shutdownbtn.place(x=195,y=450)


    userlogo = customtkinter.CTkLabel(sidebar,text='👤',fg_color='transparent',text_color='white',font=customtkinter.CTkFont(size=20,weight='bold'))
    userlogo.place(x=15,y=455)

    username = customtkinter.CTkLabel(sidebar,text='admin',fg_color='transparent',text_color='white',font=customtkinter.CTkFont(family="Arial",size=15,slant="italic",underline=1))
    username.place(x=40,y=457)


    # -------------------------------------
    def get_selected_value(text):

        if text == "details":
            for widget in widgd.winfo_children():
                widget.destroy()
            submitdetails()
            opt.set("OptionMenu")

        elif text == "home":
            for widget in widgd.winfo_children():
                widget.destroy()

            homemenu()
            opt.set("OptionMenu")
        elif text == "page2":
            for widget in widgd.winfo_children():
                widget.destroy()
            us2()
            opt.set("OptionMenu")
        elif text == "guide":
            for widget in widgd.winfo_children():
                widget.destroy()
            guide()
            opt.set("OptionMenu")
        elif text == "test":
            for widget in widgd.winfo_children():
                widget.destroy()
            testm()
            opt.set("OptionMenu")



    def optswitcher(choi):
        if choi == "HOME":
            for widget in widgd.winfo_children():
                widget.destroy()
            homemenu()
        elif choi == "Test":
            for widget in widgd.winfo_children():
                widget.destroy()
            testm()
        elif choi == "Guide":
            for widget in widgd.winfo_children():
                widget.destroy()
            guide()

            
            
        
    def aboutus():

            # Create content area
            
            # School logo/image placeholder
            logo_label = customtkinter.CTkLabel(
                widgd,
                text="🏫",
                font=customtkinter.CTkFont(size=80),
                text_color="#0f3b43"
            )
            logo_label.place(relx=0.5, rely=0.2, anchor="center")
            
            # # Mission statement
            mission_label = customtkinter.CTkLabel(
                widgd,
                text="Our Mission",
                font=customtkinter.CTkFont(size=18, weight="bold"),
                text_color="#0f3b43"
            )
            mission_label.place(relx=0.5, rely=0.4, anchor="center")
            
            mission_text = customtkinter.CTkLabel(
                widgd,
                text="To create a secure and efficient monitoring system that enhances\n"
                    "the educational experience for students, teachers, and administrators.",
                font=customtkinter.CTkFont(size=13),
                text_color="#333333"
            )
            mission_text.place(relx=0.5, rely=0.5, anchor="center")
            
            # About the system
            about_label = customtkinter.CTkLabel(
                widgd,
                text="About Our System",
                font=customtkinter.CTkFont(size=18, weight="bold"),
                text_color="#0f3b43"
            )
            about_label.place(relx=0.5, rely=0.6, anchor="center")
            
            about_text = customtkinter.CTkLabel(
                widgd,
                text="The School Monitoring System is designed to streamline administrative tasks,\n"
                    "improve communication between staff and students, and provide real-time\n"
                    "insights into academic performance and attendance.\n\n"
                    "Our system integrates with existing school infrastructure to provide\n"
                    "a comprehensive solution for modern educational institutions.",
                font=customtkinter.CTkFont(size=11),
                text_color="#333333",
                justify="left"
            )
            about_text.place(x=210,y=330, anchor="center")


    def us2():

            logo_label2 = customtkinter.CTkLabel(
                widgd,
                text="🏫",
                font=customtkinter.CTkFont(size=80),
                text_color="#0f3b43"
            )
            logo_label2.place(relx=0.5, rely=0.2, anchor="center")
            
            # # Mission statement
            mission_label2 = customtkinter.CTkLabel(
                widgd,
                text="Our Mission",
                font=customtkinter.CTkFont(size=18, weight="bold"),
                text_color="#0f3b43"
            )
            mission_label2.place(relx=0.5, rely=0.4, anchor="center")
            
            mission_text2 = customtkinter.CTkLabel(
                widgd,
                text="To create a secure and efficient monitoring system that enhances\n"
                    "the educational experience for students, teachers, and administrators.",
                font=customtkinter.CTkFont(size=13),
                text_color="#333333"
            )
            mission_text2.place(relx=0.5, rely=0.5, anchor="center")
            
            # About the system
            about_label2 = customtkinter.CTkLabel(
                widgd,
                text="About Our System",
                font=customtkinter.CTkFont(size=18, weight="bold"),
                text_color="#0f3b43"
            )
            about_label2.place(relx=0.5, rely=0.6, anchor="center")
            
            about_text2 = customtkinter.CTkLabel(
                widgd,
                text="The School Monitoring System is designed to streamline administrative tasks,\n"
                    "improve communication between staff and students, and provide real-time\n"
                    "insights into academic performance and attendance.\n\n"
                    "Our system integrates with existing school infrastructure to provide\n"
                    "a comprehensive solution for modern educational institutions.",
                font=customtkinter.CTkFont(size=11),
                text_color="#333333",
                justify="left"
            )
            about_text2.place(x=210,y=330, anchor="center")


    opt =customtkinter.CTkOptionMenu(win,values=["HOME","Test","Guide","OptionMenu",],fg_color="#ffffff",command=optswitcher,text_color="#333333",button_color="#dddddd",button_hover_color="#cccccc",dropdown_fg_color="#ffffff",dropdown_hover_color="#eeeeee",dropdown_text_color="#333333",width=250)
    opt.place(x=260,y=6)
    opt.set("OptionMenu")
    def homemenu():
        # chec3.configure(state="disabled", fg_color="gray70")
        # chec2.configure(state="disabled", fg_color="gray70")

        altick1 = customtkinter.BooleanVar(value=True)
        altick2 = customtkinter.BooleanVar(value=True)

        

        chec1= customtkinter.CTkCheckBox(widgd,width=1,height=1,text="Send Data Via TG Bot",fg_color="#37c79c",bg_color="white",text_color="#137880",hover_color="#37c79c",variable=altick1)
        chec1.place(x=235,y=307)

        chec2=customtkinter.CTkCheckBox(widgd,width=1,state="disable",height=1,bg_color="gray70",text="Send Data Via Whatsapp\nunder(maintenance)",fg_color="#37c79c",text_color="#137880",hover_color="#37c79c")


        chec2.place(x=235,y=347)
        chec3=customtkinter.CTkCheckBox(widgd,width=1,state="disable",height=1,text="Track after 9:00 am(um)",bg_color="gray70",fg_color="#37c79c",text_color="#137880",hover_color="#37c79c")
        chec3.place(x=25,y=307)
        chec4=customtkinter.CTkCheckBox(widgd,width=1,height=1,text="All Time Track",fg_color="#37c79c",bg_color="white",text_color="#137880",hover_color="#37c79c",variable=altick2)
        chec4.place(x=25,y=347)
        msbtn =customtkinter.CTkButton(widgd,text="                    Start Tracking",command=trackp,fg_color="#0f3b43",hover_color="#164a52",anchor="w",height=40,width=220,corner_radius=8,text_color="white")
        msbtn.place(x=100,y=397)
        sper = customtkinter.CTkLabel(widgd,text="___________________________________________________________",bg_color="white",fg_color="transparent",font=customtkinter.CTkFont(size=17),text_color="#0e2d33")
        sper.place(x=6,y=270)
        # customtkinter.CTkLabel(widgd,height=40,width=10,text="यह सॉफ़्टवेयर मानक इंस्पायर पुरस्कार प्रदर्शनी के लिए बनाया गया है इस सॉफ़्टवेयर का उद्देश्य यह है कि",).place(x=250,y=80)


    def submitdetails():

        school_label = customtkinter.CTkLabel(widgd, text="School Name:", text_color="black")
        school_label.place(x=30, y=30)
        school_entry = customtkinter.CTkEntry(widgd, width=350)
        school_entry.place(x=30, y=60)

        key_label = customtkinter.CTkLabel(widgd, text="Key:", text_color="black")
        key_label.place(x=30, y=100)
        key_entry = customtkinter.CTkEntry(widgd, width=350)
        key_entry.place(x=30, y=130)

        chat_id_label = customtkinter.CTkLabel(widgd, text="Chat ID:", text_color="black")
        chat_id_label.place(x=30, y=170)
        chat_id_entry = customtkinter.CTkEntry(widgd, width=350)
        chat_id_entry.place(x=30, y=200)

        message_label = customtkinter.CTkLabel(widgd, text="Custom Message:", text_color="black")
        message_label.place(x=30, y=240)
        message_entry = customtkinter.CTkEntry(widgd, width=350)
        message_entry.place(x=30, y=270)



        key_entry.configure(state="disabled", fg_color="gray70")
        chat_id_entry.configure(state="disabled", fg_color="gray70")
        def toggle_fields():
            if disable_var.get() == 1:   # Checkbox checked
                key_entry.configure(state="disabled", fg_color="gray70")
                chat_id_entry.configure(state="disabled", fg_color="gray70")
            else:
                key_entry.configure(state="normal", fg_color="white")
                chat_id_entry.configure(state="normal", fg_color="white")



        disable_var = customtkinter.BooleanVar(value=True)

        checkboxds = customtkinter.CTkCheckBox(widgd,200,text="Use Default Key And Chat ID",fg_color="#37c79c",command=toggle_fields,bg_color="white",text_color="#137880",hover_color="#37c79c",variable=disable_var)
        checkboxds.place(x=30,y=330)

        # Submit Button
        def on_submit():
            school = school_entry.get()
            key = key_entry.get()
            chat_id = chat_id_entry.get()
            message = message_entry.get()
            with open("cred/school.txt", "w") as s:
                s.write(school)

            with open("cred/key.txt", "w") as k:
                k.write(key)


            with open("cred/chat.txt", "w") as c:
                c.write(chat_id)

            with open("cred/msg.txt", "w") as m:
                m.write(message)

            
            print("Submitted:", school, key, chat_id, message)
            submit_button.configure(text="                             done ✓")  # You can replace this with any logic

        submit_button = customtkinter.CTkButton(widgd, text="                           Submit", command=on_submit,fg_color="#0f3b43",hover_color="#164a52",anchor="w",height=40,width=220)
        submit_button.place(relx=0.5, rely=0.9, anchor="center")

    def guide():
        guie = customtkinter.CTkLabel(
                widgd,
                text="guide window\nunder(maintenance)",
                font=customtkinter.CTkFont(size=18, weight="bold"),
                text_color="#0f3b43"
            )
        guie.place(relx=0.5, rely=0.4, anchor="center")
    def run_anticheat():
        subprocess.Popen(["python", "trakinghead/acheat.py"])
    def testm():
        # 🔴 TOP RED HEADER
        header = customtkinter.CTkFrame(widgd,fg_color="#b91c1c",corner_radius=10)
        header.place(relx=0.5, rely=0.12, anchor="center")

        header_label = customtkinter.CTkLabel(header,text="TEST MODE ACTIVE",font=customtkinter.CTkFont(size=16, weight="bold"),text_color="white")
        header_label.pack(padx=20, pady=10)

        # 🔵 MAIN INFO BOX
        info_frame = customtkinter.CTkFrame(widgd,fg_color="#e0f2fe",corner_radius=10)
        info_frame.place(relx=0.5, rely=0.31, anchor="center")

        info_label = customtkinter.CTkLabel(info_frame,
            text=("You are currently in the Test Window of the software.\nThis version is in Development / Beta Stage."),font=customtkinter.CTkFont(size=14, weight="bold"),text_color="#0f3b43",justify="center")
        info_label.pack(padx=20, pady=15)

        # 🟠 WARNING BOX
        warning_frame = customtkinter.CTkFrame(widgd,fg_color="#fff7ed",corner_radius=10)
        warning_frame.place(relx=0.5, rely=0.49, anchor="center")

        warning_label = customtkinter.CTkLabel(warning_frame,text=("• Some functions may not work correctly\n• Data inconsistencies may occur\n• Unexpected errors may appear"),font=customtkinter.CTkFont(size=13, weight="bold"),text_color="#9a3412",justify="left")
        warning_label.pack(padx=20, pady=15)


        # 🟢 SUCCESS / FINAL NOTE
        success_frame = customtkinter.CTkFrame(widgd,fg_color="#ecfdf5",corner_radius=10)
        success_frame.place(relx=0.5, rely=0.71, anchor="center")

        success_label = customtkinter.CTkLabel(success_frame,text=("Once this code becomes stable and fully functional,\nit will be permanently added to the Main Menu.\n\nYour feedback is very important to us 🙏"),font=customtkinter.CTkFont(size=13, weight="bold"),text_color="#065f46",justify="center")
        success_label.pack(padx=20, pady=15)



        msbtn2 =customtkinter.CTkButton(widgd,text="                    Start Tracking",command=lambda: threading.Thread(target=run_anticheat, daemon=True).start(),fg_color="#0f3b43",hover_color="#164a52",anchor="w",height=40,width=220,corner_radius=8,text_color="white")
        msbtn2.place(x=100,y=385)
    


    optswitcher("HOME")
    win.mainloop()

import cv2
import numpy as np
from tracker import*
import cvzone
import time,requests
prev_p_out = 0
prev_p_in = 0

def sclname():
    with open(f"cred/school.txt", 'r', encoding='utf-8') as f:
        schooln = f.read()
    if schooln == "":
        return "राजकीयकृत +2 हाई स्कूल दुग्दा"
    else:
        return schooln
def key():
    with open("cred/key.txt", 'r', encoding='utf-8') as f:
        token = f.read()
    if token == "":
        return "8441061070:AAG2hNiGxaW7AwuxL0Wfr-gSnBvx1sATf10"
    else:
        return token
    
def msg():
    with open("cred/msg.txt", 'r', encoding='utf-8') as f:
        mesg = f.read()
    if mesg == "":
        return "1"
    else:
        return mesg
    
def chatid():
    with open("cred/chat.txt", 'r', encoding='utf-8') as f:
        chat = f.read()
    if chat == "":
        return "5420382341"
    else:
        return chat


def trackp():
    global prev_p_in,prev_p_out
    bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=200, varThreshold=40)

# Open a video capture
    video_capture = cv2.VideoCapture('video/headcount2.mp4')
    def RGB(event, x, y, flags, param):
        if event == cv2.EVENT_MOUSEMOVE :  
            point = [x, y]
            print(point)
  
        

    cv2.namedWindow('RGB')
    cv2.setMouseCallback('RGB', RGB)
    tracker=Tracker()
    cy1=253  
    cy2=223
    cy3=121

    offset=6

    going_in={}
    counter1=[]
    going_out={}
    counter2=[]


    count=0
    while True:
        ret, frame = video_capture.read()
        if not ret:
            break
        count += 1
        if count % 3 != 0:
            continue
    
        frame=cv2.resize(frame,(500,480))
  
        mask = bg_subtractor.apply(frame)
        _, mask = cv2.threshold(mask, 245, 255, cv2.THRESH_BINARY)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        list=[]
        for cnt in contours:
            area = cv2.contourArea(cnt)
            if area > 500:
#           cv2.drawContours(frame, [cnt], -1, (0, 255, 0), 2)
               x, y, w, h = cv2.boundingRect(cnt)
               list.append([x,y,w,h])
        bbox_idx=tracker.update(list)
        for bbox in bbox_idx:
            x1,y1,x2,y2,id=bbox
            cx=int(x1+x1+x2)//2
            cy=int(y1+y1+y2)//2
#        cv2.rectangle(frame, (x1, y1), (x2+x1, y2+y1), (255, 0, 0), 3)
#        cvzone.putTextRect(frame,f'{id}',(x1,y1),2,2)
#        cv2.circle(frame,(cx,cy),4,(255,0,255),-1)
        
        
            if cy1<(cy+offset) and cy1>(cy-offset):
               going_out[id]=(cx,cy)
            if id in going_out:
               if cy3<(cy+offset) and cy3>(cy-offset):
                  cv2.rectangle(frame, (x1, y1), (x2+x1, y2+y1), (255, 0, 255), 3)
                  cvzone.putTextRect(frame,f'{id-1}',(x1,y1),2,2)
                  cv2.circle(frame,(cx,cy),4,(255,0,255),-1)
                  counter1.append(id)
            if cy2<(cy+offset) and cy2>(cy-offset):      
               going_in[id]=(cx,cy)
            if id in going_in:
               if cy1<(cy+offset) and cy1>(cy-offset):
                  cv2.rectangle(frame, (x1, y1), (x2+x1, y2+y1), (0, 0, 255), 3)
                  cvzone.putTextRect(frame,f'{id}',(x1,y1),2,2)
                  cv2.circle(frame,(cx,cy),4,(255,0,255),-1)
                  counter2.append(id)
                
                  

        # cv2.line(frame,(10,cy1),(598,cy1),(255,255,255),2)
        # cv2.line(frame,(8,cy2),(598,cy2),(255,255,255),2)
        # cv2.line(frame,(10,cy3),(596,cy3),(255,255,255),2)
    
        # cvzone.putTextRect(frame,f'line1',(10,253),1,1)
        # cvzone.putTextRect(frame,f'line2',(288,225),1,1)
        # cvzone.putTextRect(frame,f'line3',(552,118),1,1)


        # p_out=len(counter1)
        # p_in=len(counter2)
        
        # cvzone.putTextRect(frame,f'OUT:-{p_out}',(50,60),1,1)
        # cvzone.putTextRect(frame,f'IN:-{p_in}',(428,56),1,1)


        # Draw plain lines
        cv2.line(frame, (10, cy1), (598, cy1), (153,255,153), 2)
        cv2.line(frame, (8, cy2), (598, cy2), (255,255,102), 2)
        cv2.line(frame, (10, cy3), (596, cy3), (255, 255, 255), 2)

        # Plain text instead of cvzone.putTextRect
        cv2.putText(frame, 'line1', (10, cy1 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (153,255,153), 2)
        cv2.putText(frame, 'line2', (288, cy2 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255,255,102), 2)
        cv2.putText(frame, 'line3', (552, cy3 - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)

        # People count
        p_out = len(set(counter1))
        p_in = len(set(counter2))
        cv2.putText(frame, f'OUT:-{p_out}', (50, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (102,172,0), 2)
        cv2.putText(frame, f'IN:-{p_in}', (428, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.8, (102,172,0), 2)
        # if p_out is < id2:

        
        if p_out > prev_p_out or p_in > prev_p_in:

            _, img_encoded = cv2.imencode('.jpg', frame)
            img_bytes = img_encoded.tobytes()
            TOKEN = key()  # Replace with your actual token
            CHAT_ID = chatid()
            url = f'https://api.telegram.org/bot{TOKEN}/sendPhoto'
            school_name = sclname()
            system_name = "𝐒𝐜𝐡𝐨𝐨𝐥 𝐌𝐨𝐧𝐢𝐭𝐨𝐫𝐢𝐧𝐠 𝐒𝐲𝐬𝐭𝐞𝐦"
            current_time = time.localtime()
            formatted_date = time.strftime("%d/%m/%Y", current_time)
            formatted_time = time.strftime("%I:%M %p", current_time)
            amanjit=msg()
            # Construct the caption
            caption = f"""
{school_name}
------------------------------------------------
{system_name}
------------------------------------------------

Date: {formatted_date}
Time: {formatted_time}

Message:
{amanjit}

धन्यवाद,
            """

        # Prepare the files and data for the request
            files = {'photo': ('image.jpg', img_bytes)}
            data = {'chat_id': CHAT_ID, 'caption': caption}

            response = requests.post(url, files=files, data=data)
            print(response.json())

        
        # Update previous values
        prev_p_out = p_out
        prev_p_in = p_in




        cv2.imshow('RGB', frame)
        time.sleep(0.1)
        if cv2.waitKey(650) & 0xFF == 27:  # Press 'Esc' to exit
            break

# Release the video capture and close windows
    video_capture.release()
    cv2.destroyAllWindows()















# _, img_encoded = cv2.imencode('.jpg', frame)
#                   img_bytes = img_encoded.tobytes()
#                   TOKEN = '8441061070:AAG2hNiGxaW7AwuxL0Wfr-gSnBvx1sATf10'  # Replace with your actual token
#                   CHAT_ID = '5420382341'
#                   url = f'https://api.telegram.org/bot{TOKEN}/sendPhoto'
#                   school_name = "राजकीयकृत +2 हाई स्कूल दुग्दा"
#                   system_name = "𝐒𝐜𝐡𝐨𝐨𝐥 𝐌𝐨𝐧𝐢𝐭𝐨𝐫𝐢𝐧𝐠 𝐒𝐲𝐬𝐭𝐞𝐦"
#                   current_time = time.localtime()
#                   formatted_date = time.strftime("%d/%m/%Y", current_time)
#                   formatted_time = time.strftime("%I:%M %p", current_time)
#                   amanjit=1
#                   # Construct the caption
#                   caption = f"""
# {school_name}
# ------------------------------------------------
# {system_name}
# ------------------------------------------------

# Date: {formatted_date}
# Time: {formatted_time}

# Message:
# {amanjit}

# धन्यवाद,
#                   """

#                 # Prepare the files and data for the request
#                   files = {'photo': ('image.jpg', img_bytes)}
#                   data = {'chat_id': CHAT_ID, 'caption': caption}

#                   response = requests.post(url, files=files, data=data)
#                   print(response.json())